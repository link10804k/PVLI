pad(3); // Resultado predicho: 03

console.log(pad(3)); // Resultado devuelto: 03

pad(2, 5); // Resultado predicho: 00002

console.log(pad(2, 5)); // Resultado devuelto: 00002

pad(2, 5, '*'); // Resultado predicho: ****2

console.log(pad(2, 5, '*')); // Resultado devuelto: ****2
